<template>
  <div class="seller">
    我是 seller
  </div>
</template>

<script type="text/ecmascript-6">
export default {};
</script>

<style lang="scss" rel="stylesheet/scss">
</style>
